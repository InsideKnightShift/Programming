Plugin to make object for game KnightShift.

Needed program 3D Studio Max 4.1

We think that program is installed in folder: c:\3dsmax4
if not you have to change a path in file Polanie txt.



1.Content

GamePlugin.DLO  - file with code of plugin
Polanie.txt  - configuration file for plugin
GameHelp.txt - help file


2. Installation

These 3 files you must copy to directory c:\3dsmax4\plugins




