Plugin do tworzenia obiektow do gry KnightShift.

Wymagany program 3D Studio Max 4.1

Zak�adamy �e program jest zainstalowany w katalogu: c:\3dsmax4
W przeciwnym wypadku nalezy zmieni� scie�ki w pliku Polanie txt.



1.Zawarto��

GamePlugin.DLO  - plik z kodem plugina
Polanie.txt  - plik konfiguracyjny do plugina
GameHelp.txt - plik pomocy


2. Instalacja

Powyzsze 3 pliki skopiowac do katalogu c:\3dsmax4\plugins


